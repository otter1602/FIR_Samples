import tkinter as tk
from tkinter import ttk, filedialog
import numpy as np
from scipy import signal
import matplotlib.pyplot as plt
import csv

def design_fir_filter():
    try:
        cutoff = float(entry_cutoff.get())
        fs = float(entry_fs.get())
        numtaps = int(entry_tap.get())

        pass_gain = float(entry_pass_gain.get())
        stop_gain = float(entry_stop_gain.get())

        method = combo_method.get()
        nyq = fs / 2

        if cutoff <= 0 or cutoff >= nyq:
            raise ValueError("カットオフ周波数は0より大きく、(サンプリング周波数 / 2)未満 にしてください")

        if numtaps <= 0 or numtaps >= int(fs*2):
            raise ValueError("フィルタ次数はサンプリング周波数 * 2未満にしてください")

        if method == "窓関数法":
            coeffs = signal.firwin(numtaps, cutoff, window="hamming", fs=fs, pass_zero='lowpass')
        elif method == "フーリエ変換法":
            freqs = [0, cutoff, cutoff + 0.05 * fs, nyq]
            gains = [pass_gain, pass_gain, stop_gain, stop_gain]
            coeffs = signal.firwin2(numtaps, freqs, gains, fs=fs)
        elif method == "最小二乗法":
            bands = [0, cutoff, cutoff + 0.05 * fs, nyq]
            desired = [pass_gain, pass_gain, stop_gain, stop_gain]
            coeffs = signal.firls(numtaps, bands, desired, fs=fs)
        elif method == "Remez":
            bands = [0, cutoff, cutoff + 0.05 * fs, nyq]
            desired = [pass_gain, stop_gain]
            coeffs = signal.remez(numtaps, bands, desired, fs=fs)
        else:
            raise ValueError("無効なアルゴリズム選択です")

        # 周波数応答プロット
        w, h = signal.freqz(coeffs, worN=8000, fs=fs)
        plt.figure(figsize=(10, 4))

        plt.subplot(1, 2, 1)
        plt.plot(w, 20 * np.log10(np.abs(h)))
        plt.title("Frequency Response")
        plt.xlabel("Frequency [Hz]")
        plt.ylabel("Amplitude [dB]")
        plt.grid(True)
        plt.ylim(-100, 5)

        # インパルス応答プロット
        plt.subplot(1, 2, 2)
        plt.stem(coeffs)
        plt.title("Impulse Response")
        plt.xlabel("Taps")
        plt.ylabel("Amplitude")
        plt.grid(True)

        plt.tight_layout()

        # 位相特性とステップ応答時間のグラフ化
        fig2, axs2 = plt.subplots(1, 2, figsize=(10, 4))
        # 位相特性
        phase = np.unwrap(np.angle(h))  # 位相をアンラップ
        axs2[0].plot(w, np.degrees(phase))
        axs2[0].set_title("Phase Response")
        axs2[0].set_xlabel("Frequency [Hz]")
        axs2[0].set_ylabel("Phase [degrees]")
        axs2[0].grid(True)

        # ステップ応答
        step = np.cumsum(coeffs)  # FIRのステップ応答はインパルス応答の積分
        axs2[1].plot(np.arange(len(step)) / fs, step)
        axs2[1].set_title("Step Response")
        axs2[1].set_xlabel("Time [s]")
        axs2[1].set_ylabel("Amplitude")
        axs2[1].grid(True)

        # 99%到達時間の計算
        threshold = 0.99 * step[-1]
        idx_99 = np.argmax(step >= threshold)
        t_99 = idx_99 / fs
        axs2[1].axvline(t_99, color='r', linestyle='--', label=f"99% at {t_99:.4f} s")
        axs2[1].legend()

        fig2.tight_layout()
        plt.show()


        # 保存用に係数をグローバルに保存
        global last_coeffs
        last_coeffs = coeffs
        lbl_result["text"] = "フィルタ設計成功!"

    except ValueError as e:
        lbl_result["text"] = f"エラー: {str(e)}"

def save_coeffs():
    if last_coeffs is None:
        lbl_result["text"] = "設計したフィルタがありません"
        return
    filepath = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
    if filepath:
        with open(filepath, "w", newline="") as f:
            writer = csv.writer(f)
            for c in last_coeffs:
                writer.writerow([c])
        lbl_result["text"] = f"係数を保存しました: {filepath}"

# GUIセットアップ
root = tk.Tk()
root.title("FIRローパスフィルタ設計")

tk.Label(root, text="サンプリング周波数 [Hz]:").grid(row=0, column=0, padx=10, pady=5)
entry_fs = tk.Entry(root)
entry_fs.insert(0, "1000")
entry_fs.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root, text="カットオフ周波数 [Hz]:").grid(row=1, column=0, padx=10, pady=5)
entry_cutoff = tk.Entry(root)
entry_cutoff.insert(0, "200")
entry_cutoff.grid(row=1, column=1, padx=10, pady=5)

tk.Label(root, text="フィルタ次数:").grid(row=2, column=0, padx=10, pady=5)
entry_tap = tk.Entry(root)
entry_tap.insert(0, "101")
entry_tap.grid(row=2, column=1, padx=10, pady=5)

tk.Label(root, text="通過帯域ゲイン:").grid(row=3, column=0, padx=10, pady=5)
entry_pass_gain = tk.Entry(root)
entry_pass_gain.insert(0, "1")
entry_pass_gain.grid(row=3, column=1, padx=10, pady=5)

tk.Label(root, text="阻止帯域ゲイン:").grid(row=4, column=0, padx=10, pady=5)
entry_stop_gain = tk.Entry(root)
entry_stop_gain.insert(0, "0")
entry_stop_gain.grid(row=4, column=1, padx=10, pady=5)

tk.Label(root, text="設計アルゴリズム:").grid(row=5, column=0, padx=10, pady=5)
combo_method = ttk.Combobox(root, values=["窓関数法", "フーリエ変換法", "最小二乗法", "Remez"])
combo_method.grid(row=5, column=1, padx=10, pady=5)
combo_method.current(0)

btn_design = tk.Button(root, text="設計して表示", command=design_fir_filter)
btn_design.grid(row=6, column=0, columnspan=2, pady=10)

btn_save = tk.Button(root, text="係数をCSV保存", command=save_coeffs)
btn_save.grid(row=7, column=0, columnspan=2, pady=5)

lbl_result = tk.Label(root, text="")
lbl_result.grid(row=8, column=0, columnspan=2)

last_coeffs = None  # 初期化
root.mainloop()
