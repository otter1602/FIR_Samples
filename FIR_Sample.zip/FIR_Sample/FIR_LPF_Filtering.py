import tkinter as tk
from tkinter import ttk, filedialog
import numpy as np
from scipy import signal
import matplotlib.pyplot as plt
import csv

def browse_file(entry_widget):
    filepath = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if filepath:
        entry_widget.delete(0, tk.END)
        entry_widget.insert(0, filepath)

def apply_filter_to_timeseries():
    try:
        coeff_path = entry_coeff_path.get()
        data_path = entry_data_path.get()
        if not coeff_path or not data_path:
            raise ValueError("CSVパスが指定されていません")

        coeffs = []
        with open(coeff_path, newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                coeffs.append(float(row[0]))

        time = []
        value = []
        with open(data_path, newline="") as f:
            reader = csv.reader(f)
            next(reader)  # ヘッダスキップ
            for row in reader:
                time.append(float(row[0]))
                value.append(float(row[1]))

        filtered = signal.lfilter(coeffs, [1.0], value)

        plt.figure(figsize=(10, 4))
        plt.plot(time, value, label="Original")
        plt.plot(time, filtered, label="Filtered", linewidth=2)
        plt.title("Time Series Filtering Result")
        plt.xlabel("Time [s]")
        plt.ylabel("Value")
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.show()

        # 保存
        save_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if save_path:
            with open(save_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["time", "value", "filtered_value"])
                for t, v, fv in zip(time, value, filtered):
                    writer.writerow([t, v, fv])
            lbl_result["text"] = f"フィルタ結果を保存しました: {save_path}"
    except Exception as e:
        lbl_result["text"] = f"フィルタ適用エラー: {str(e)}"

# GUI setup
root = tk.Tk()
root.title("FIRローパスフィルタ適用")

tk.Label(root, text="係数CSVパス:").grid(row=8, column=0, padx=10, pady=5)
entry_coeff_path = tk.Entry(root, width=40)
entry_coeff_path.grid(row=8, column=1, padx=10, pady=5)
tk.Button(root, text="参照", command=lambda: browse_file(entry_coeff_path)).grid(row=8, column=2)

tk.Label(root, text="時系列CSVパス:").grid(row=9, column=0, padx=10, pady=5)
entry_data_path = tk.Entry(root, width=40)
entry_data_path.grid(row=9, column=1, padx=10, pady=5)
tk.Button(root, text="参照", command=lambda: browse_file(entry_data_path)).grid(row=9, column=2)

btn_apply = tk.Button(root, text="フィルタ適用", command=apply_filter_to_timeseries)
btn_apply.grid(row=10, column=0, columnspan=3, pady=10)

lbl_result = tk.Label(root, text="")
lbl_result.grid(row=11, column=0, columnspan=3)

last_coeffs = None
root.mainloop()
