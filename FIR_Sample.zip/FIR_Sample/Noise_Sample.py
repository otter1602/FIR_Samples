import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# パラメータ
fs = 1000  # サンプリング周波数 [Hz]
duration = 1.0  # 秒
t = np.arange(0, duration, 1/fs)

# 基本信号（10Hzの正弦波）
signal_base = np.sin(2 * np.pi * 10 * t)

# ノイズを追加した信号
noise_400Hz = np.sin(2 * np.pi * 400 * t)
signal_with_400Hz = signal_base + 0.5 * noise_400Hz

noise_100Hz = np.sin(2 * np.pi * 100 * t)
signal_with_100Hz = signal_base + 0.5 * noise_100Hz

# プロットで確認
plt.figure(figsize=(12, 5))
plt.subplot(2, 1, 1)
plt.plot(t, signal_with_400Hz, label="10Hz + 400Hz")
plt.title("10Hz Sine Wave with 400Hz Noise")
plt.xlabel("Time [s]")
plt.ylabel("Amplitude")
plt.grid(True)

plt.subplot(2, 1, 2)
plt.plot(t, signal_with_100Hz, label="10Hz + 100Hz")
plt.title("10Hz Sine Wave with 100Hz Noise")
plt.xlabel("Time [s]")
plt.ylabel("Amplitude")
plt.grid(True)

plt.tight_layout()
plt.show()

# CSV形式で保存用データフレーム作成
df_400 = pd.DataFrame({'time': t, 'value': signal_with_400Hz})
df_100 = pd.DataFrame({'time': t, 'value': signal_with_100Hz})

# ファイルに保存
df_400_path = "sample_signal_10Hz_plus_400Hz.csv"
df_100_path = "sample_signal_10Hz_plus_100Hz.csv"
df_400.to_csv(df_400_path, index=False)
df_100.to_csv(df_100_path, index=False)

df_400_path, df_100_path
